#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#include <spawn.h>

@interface RAPRootListController : PSListController

- (void)apply;

@end
